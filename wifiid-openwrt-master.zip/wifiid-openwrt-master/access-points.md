### **Ciri-ciri Pemancar sinyal @wifi.id yang Bisa Dipakai**

Mudahnya, hampir semua pemancar sinyal @wifi.id yang bisa dipakai ada stiker logo @wifi.id, tapi ada saja beberapa pemancar yang tidak ada stikernya, entah memang dari awalnya tidak terpasang atau memang dilepas. Berikut adalah beberapa merk dan tipe yang bisa dijumpai di lapangan:

1. Autelan

Merk ini setahu saya merupakan salah satu merk yang paling lama ada dan banyak tersebar di tempat-tempat umum, seperti alun-alun, plasa telkom, sekolah negeri, puskesmas, dll.

![autelan](pics/autelan-1.png)

Pemancar dari merk ini ada 3 tipe: indoor tanpa antena, indoor dengan antena dan outdoor.
Bentuk fisiknya bisa dilihat di gambar berikut:

![autelan-variants](pics/autelan-2.png)

Untuk yang tipe outdoor, terdapat 4 antena panjang ketika terpasang di lapangan, seperti berikut:

![autelan-outdoor](pics/autelan-3.png)

2. Cisco

Merk ini setahu saya biasanya dipakai sebagai pengganti Autelan atau untuk keperluan WMS. Setidaknya ada 3 tipe:

![cisco-1](pics/cisco-1.png)  
![cisco-2](pics/cisco-2.png)  
![cisco-3](pics/cisco-3.png)

3. Huawei

Penulis belum mendapatkan informasi lebih lanjut soal merk ini, mungkin dipakai untuk keperluan WMS di beberapa daerah.

![huawei](pics/huawei-1.png)